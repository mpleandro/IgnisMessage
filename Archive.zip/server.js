const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const express = require('express');

const PORT = process.env.PORT || 3000;
const APP_USER = process.env.APP_USER || 'admin';
const APP_PASSWORD = process.env.APP_PASSWORD || '';

const app = express();
app.use(express.json({ limit: '50mb' }));

// ---------- Autenticação (tela de login + cookie de sessão assinado) ----------
app.set('trust proxy', true);
const SESSION_SECRET = process.env.SESSION_SECRET ||
  crypto.createHash('sha256').update('disparador|' + APP_PASSWORD).digest('hex');
const SESSION_TTL_MS = 7 * 24 * 3600 * 1000;
const COOKIE = 'disp_session';

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}
const sign = (v) => crypto.createHmac('sha256', SESSION_SECRET).update(v).digest('base64url');
function makeToken() {
  const payload = Buffer.from(JSON.stringify({ u: APP_USER, exp: Date.now() + SESSION_TTL_MS })).toString('base64url');
  return payload + '.' + sign(payload);
}
function validToken(token) {
  const [payload, sig] = String(token || '').split('.');
  if (!payload || !sig || !safeEqual(sig, sign(payload))) return false;
  try {
    const d = JSON.parse(Buffer.from(payload, 'base64url').toString());
    return d.u === APP_USER && d.exp > Date.now();
  } catch { return false; }
}
function getCookie(req, name) {
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0 && part.slice(0, i).trim() === name) return decodeURIComponent(part.slice(i + 1).trim());
  }
  return '';
}
const isAuthed = (req) => !APP_PASSWORD || validToken(getCookie(req, COOKIE));

// limite de tentativas por IP: 8 falhas / 10 min
const attempts = new Map();
function tooMany(ip) {
  const a = attempts.get(ip);
  return a && a.until > Date.now() && a.count >= 8;
}
function noteFail(ip) {
  const a = attempts.get(ip);
  if (!a || a.until < Date.now()) attempts.set(ip, { count: 1, until: Date.now() + 10 * 60 * 1000 });
  else a.count++;
}

// Assets visuais (logo) são públicos para a tela de login poder usá-los.
app.use('/assets', express.static(path.join(__dirname, 'public', 'assets')));

app.get('/login', (req, res) => {
  if (isAuthed(req)) return res.redirect('/');
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/api/login', (req, res) => {
  const ip = req.ip;
  if (tooMany(ip)) return res.status(429).json({ error: 'Muitas tentativas. Aguarde alguns minutos.' });
  const { user, password } = req.body || {};
  if (APP_PASSWORD && safeEqual(user || '', APP_USER) && safeEqual(password || '', APP_PASSWORD)) {
    attempts.delete(ip);
    res.cookie(COOKIE, makeToken(), {
      httpOnly: true, sameSite: 'lax', secure: req.secure, maxAge: SESSION_TTL_MS, path: '/',
    });
    return res.json({ ok: true });
  }
  noteFail(ip);
  res.status(401).json({ error: 'Usuário ou senha incorretos.' });
});

app.post('/api/logout', (req, res) => {
  res.clearCookie(COOKIE, { path: '/' });
  res.json({ ok: true });
});

// Arquivos de mídia anexados: servidos sem login (o N8N precisa baixá-los), protegidos por um id aleatório e imprevisível.
app.get('/media/:id/:name?', (req, res) => {
  const m = readMediaMeta(req.params.id);
  if (!m) return res.status(404).end();
  res.type(m.mimetype);
  res.set('Content-Disposition', `inline; filename*=UTF-8''${encodeURIComponent(m.name)}`);
  res.sendFile(mediaPath(m.id));
});

app.use((req, res, next) => {
  if (isAuthed(req)) return next();
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Não autenticado' });
  res.redirect('/login');
});

app.use(express.static(path.join(__dirname, 'public')));
app.use('/vendor/papaparse.min.js', (req, res) =>
  res.sendFile(require.resolve('papaparse/papaparse.min.js'))
);

// ---------- Fila de disparos ----------
const campaigns = new Map();
const ACTIVE = ['scheduled', 'running', 'paused'];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rand = (min, max) => min + Math.random() * (max - min);

// ---------- Configurações (N8N / Evolution), salvas em disco ----------
// Fora da pasta do projeto, para não se perder ao substituir/atualizar o código. No Docker: DATA_DIR=/app/data (volume).
const DATA_DIR = process.env.DATA_DIR || path.join(os.homedir(), '.disparador');
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

// ---------- Anexos (imagem / vídeo / documento) ----------
const MEDIA_DIR = path.join(DATA_DIR, 'media');
const MEDIA_MAX_BYTES = 50 * 1024 * 1024;
const MEDIA_ID_RE = /^[a-f0-9]{32}$/;
const mediaPath = (id) => path.join(MEDIA_DIR, id);
const mediaTypeOf = (mime) => (mime.startsWith('image/') ? 'image' : mime.startsWith('video/') ? 'video' : 'document');

function readMediaMeta(id) {
  if (!MEDIA_ID_RE.test(String(id))) return null;
  try { return JSON.parse(fs.readFileSync(mediaPath(id) + '.json', 'utf8')); } catch { return null; }
}

function deleteMedia(id) {
  if (!MEDIA_ID_RE.test(String(id))) return;
  for (const c of campaigns.values()) {
    if (!ACTIVE.includes(c.status)) continue;
    if ((c.steps || []).some((s) => s.media && s.media.id === id)) return; // ainda em uso por campanha ativa/agendada
  }
  fs.rmSync(mediaPath(id), { force: true });
  fs.rmSync(mediaPath(id) + '.json', { force: true });
}

// Upload como corpo bruto (octet-stream); nome em X-File-Name (URL-encoded) e tipo em X-File-Type.
app.post('/api/media', express.raw({ type: () => true, limit: MEDIA_MAX_BYTES }), (req, res) => {
  const buf = req.body;
  if (!Buffer.isBuffer(buf) || !buf.length) return res.status(400).json({ error: 'Arquivo vazio' });
  let name = 'arquivo';
  try { name = decodeURIComponent(req.headers['x-file-name'] || '') || name; } catch {}
  name = path.basename(name).replace(/[\x00-\x1f]/g, '').slice(0, 150) || 'arquivo';
  const mimetype = String(req.headers['x-file-type'] || '').split(';')[0].trim().toLowerCase() || 'application/octet-stream';
  const id = crypto.randomBytes(16).toString('hex');
  const meta = { id, name, mimetype, type: mediaTypeOf(mimetype), size: buf.length };
  try {
    fs.mkdirSync(MEDIA_DIR, { recursive: true });
    fs.writeFileSync(mediaPath(id), buf, { mode: 0o600 });
    fs.writeFileSync(mediaPath(id) + '.json', JSON.stringify(meta), { mode: 0o600 });
  } catch (e) { return res.status(500).json({ error: 'Não foi possível salvar o arquivo: ' + e.message }); }
  res.status(201).json(meta);
});

app.delete('/api/media/:id', (req, res) => {
  deleteMedia(req.params.id);
  res.json({ ok: true });
});

// Resolve o anexo enviado pelo front (apenas por id) e monta a URL pública para o N8N.
function resolveMedia(req, id) {
  if (!id) return null;
  const m = readMediaMeta(id);
  if (!m) return undefined;
  return { ...m, url: `${req.protocol}://${req.get('host')}/media/${m.id}/${encodeURIComponent(m.name)}` };
}

// Migração: versões antigas guardavam tudo em ./data dentro do projeto.
(function migrateLegacyData() {
  const legacy = path.join(__dirname, 'data');
  if (legacy === DATA_DIR || fs.existsSync(SETTINGS_FILE) || !fs.existsSync(path.join(legacy, 'settings.json'))) return;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    for (const f of ['settings.json', 'draft.json']) {
      if (fs.existsSync(path.join(legacy, f))) fs.copyFileSync(path.join(legacy, f), path.join(DATA_DIR, f));
    }
    console.log('Dados antigos migrados de', legacy, 'para', DATA_DIR);
  } catch (e) { console.warn('Falha ao migrar dados antigos:', e.message); }
})();
const DEFAULT_SETTINGS = {
  mode: 'n8n', // 'n8n' = o N8N envia | 'evolution' = o servidor chama a Evolution API direto
  n8n: { url: '', headerName: '', headerValue: '' },
  evolution: { baseUrl: '', apiKey: '', instance: '', version: 'v2' },
};

function loadSettings() {
  try {
    const saved = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    return {
      mode: saved.mode === 'evolution' ? 'evolution' : 'n8n',
      n8n: { ...DEFAULT_SETTINGS.n8n, ...saved.n8n },
      evolution: { ...DEFAULT_SETTINGS.evolution, ...saved.evolution },
    };
  } catch {
    return structuredClone(DEFAULT_SETTINGS);
  }
}

function persistSettings(s) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = SETTINGS_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(s, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, SETTINGS_FILE);
}

let settings = loadSettings();

const isHttpUrl = (u) => {
  try { return ['http:', 'https:'].includes(new URL(u).protocol); } catch { return false; }
};
const str = (v) => (typeof v === 'string' ? v.trim() : '');

// Retorna o motivo pelo qual o destino ativo não pode ser usado, ou null.
function destError(s) {
  if (s.mode === 'evolution') {
    const e = s.evolution;
    if (!isHttpUrl(e.baseUrl)) return 'Configure a URL da Evolution API em Configurações';
    if (!e.apiKey) return 'Configure a API Key da Evolution em Configurações';
    if (!e.instance) return 'Configure o nome da instância da Evolution em Configurações';
    return null;
  }
  if (!isHttpUrl(s.n8n.url)) return 'Configure a URL do webhook do N8N em Configurações';
  return null;
}

const mask = (v) => (v ? '••••••' + v.slice(-4) : '');
function publicSettings(s) {
  return {
    mode: s.mode,
    n8n: { url: s.n8n.url, headerName: s.n8n.headerName, headerValueMasked: mask(s.n8n.headerValue) },
    evolution: {
      baseUrl: s.evolution.baseUrl, instance: s.evolution.instance, version: s.evolution.version,
      apiKeyMasked: mask(s.evolution.apiKey),
    },
    ready: !destError(s),
  };
}

app.get('/api/settings', (req, res) => res.json(publicSettings(settings)));

app.put('/api/settings', (req, res) => {
  const b = req.body || {};
  const next = structuredClone(settings);
  next.mode = b.mode === 'evolution' ? 'evolution' : 'n8n';
  if (b.n8n) {
    const url = str(b.n8n.url);
    if (url && !isHttpUrl(url)) return res.status(400).json({ error: 'URL do webhook do N8N inválida (use http:// ou https://)' });
    next.n8n.url = url;
    next.n8n.headerName = str(b.n8n.headerName);
    if (typeof b.n8n.headerValue === 'string' && b.n8n.headerValue) next.n8n.headerValue = b.n8n.headerValue; // vazio = mantém
    if (!next.n8n.headerName) next.n8n.headerValue = '';
  }
  if (b.evolution) {
    const base = str(b.evolution.baseUrl).replace(/\/+$/, '');
    if (base && !isHttpUrl(base)) return res.status(400).json({ error: 'URL da Evolution API inválida (use http:// ou https://)' });
    next.evolution.baseUrl = base;
    next.evolution.instance = str(b.evolution.instance);
    next.evolution.version = b.evolution.version === 'v1' ? 'v1' : 'v2';
    if (typeof b.evolution.apiKey === 'string' && b.evolution.apiKey.trim()) next.evolution.apiKey = b.evolution.apiKey.trim(); // vazio = mantém
  }
  try { persistSettings(next); } catch (e) { return res.status(500).json({ error: 'Não foi possível salvar: ' + e.message }); }
  settings = next;
  res.json(publicSettings(settings));
});

// ---------- Rascunho do formulário (mensagem, CSV, cadência...), salvo em disco ----------
const DRAFT_FILE = path.join(DATA_DIR, 'draft.json');

function readDraft() {
  try { return JSON.parse(fs.readFileSync(DRAFT_FILE, 'utf8')); } catch { return {}; }
}
function writeDraft(d) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = DRAFT_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(d), { mode: 0o600 });
  fs.renameSync(tmp, DRAFT_FILE);
}
const validCsv = (c) => c && typeof c.name === 'string' && Array.isArray(c.headers) && Array.isArray(c.rows);

app.get('/api/draft', (req, res) => res.json(readDraft()));

app.put('/api/draft', (req, res) => {
  const cur = readDraft();
  const b = req.body || {};
  const next = {
    form: b.form && typeof b.form === 'object' ? b.form : cur.form,
    // csv ausente = mantém o que já está salvo; null = remove
    csv: b.csv === undefined ? cur.csv : (validCsv(b.csv) ? b.csv : undefined),
    savedAt: Date.now(),
  };
  try { writeDraft(next); } catch (e) { return res.status(500).json({ error: 'Não foi possível salvar: ' + e.message }); }
  res.json({ ok: true, savedAt: next.savedAt });
});

app.delete('/api/draft', (req, res) => {
  try { fs.rmSync(DRAFT_FILE, { force: true }); } catch {}
  res.json({ ok: true });
});

// ---------- Envio ----------
async function http(url, { method = 'POST', headers = {}, body } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  try {
    const res = await fetch(url, {
      method,
      headers: body === undefined ? headers : { 'Content-Type': 'application/json', ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: ctrl.signal,
    });
    const text = await res.text();
    return { ok: res.ok, status: res.status, body: text.slice(0, 300) };
  } catch (err) {
    return { ok: false, status: 0, body: err.name === 'AbortError' ? 'timeout (30s)' : err.message };
  } finally {
    clearTimeout(timer);
  }
}

const evoUrl = (e, route) => `${e.baseUrl.replace(/\/+$/, '')}${route}/${encodeURIComponent(e.instance)}`;

// Entrega UMA mensagem (um passo da sequência) pelo destino configurado (N8N ou Evolution direto).
function deliver(dest, item, meta, media) {
  if (dest.mode === 'evolution') {
    const e = dest.evolution;
    if (media) {
      let data;
      try { data = fs.readFileSync(mediaPath(media.id)).toString('base64'); }
      catch { return Promise.resolve({ ok: false, status: 0, body: 'arquivo de mídia não encontrado' }); }
      const body = e.version === 'v1'
        ? { number: item.phone, mediaMessage: { mediatype: media.type, fileName: media.name, caption: item.message, media: data } }
        : { number: item.phone, mediatype: media.type, mimetype: media.mimetype, caption: item.message, media: data, fileName: media.name };
      return http(evoUrl(e, '/message/sendMedia'), { headers: { apikey: e.apiKey }, body });
    }
    const body = e.version === 'v1'
      ? { number: item.phone, textMessage: { text: item.message } }
      : { number: item.phone, text: item.message };
    return http(evoUrl(e, '/message/sendText'), { headers: { apikey: e.apiKey }, body });
  }
  const n = dest.n8n;
  const headers = n.headerName && n.headerValue ? { [n.headerName]: n.headerValue } : {};
  return http(n.url, {
    headers,
    body: {
      ...meta, phone: item.phone, message: item.message, fields: item.fields || {},
      ...(media ? { media: { type: media.type, mimetype: media.mimetype, fileName: media.name, size: media.size, url: media.url } } : {}),
    },
  });
}

// ---------- Janela de envio (horário de Brasília) ----------
const TZ = 'America/Sao_Paulo';
const WEEKDAYS = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
const clockFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23', weekday: 'short',
});

function brasiliaNow() {
  const parts = Object.fromEntries(clockFmt.formatToParts(new Date()).map((p) => [p.type, p.value]));
  return { minutes: Number(parts.hour) * 60 + Number(parts.minute), day: WEEKDAYS[parts.weekday] };
}

function toMinutes(hhmm) {
  const [h, m] = String(hhmm).split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

function inWindow(cfg) {
  if (!cfg.windowEnabled) return true;
  const { minutes, day } = brasiliaNow();
  if (cfg.days.length && !cfg.days.includes(day)) return false;
  const start = toMinutes(cfg.windowStart);
  const end = toMinutes(cfg.windowEnd);
  if (start === end) return true;
  return start < end ? minutes >= start && minutes < end : minutes >= start || minutes < end;
}

// ---------- Persistência das campanhas (agendadas, em andamento e histórico) ----------
// Gravadas em disco para que agendamentos e disparos em andamento sobrevivam a reinícios do servidor.
const CAMPAIGNS_FILE = path.join(DATA_DIR, 'campaigns.json');
const MAX_FINISHED = 50;
let campaignsSaveTimer = null;

function saveCampaignsSoon() {
  if (campaignsSaveTimer) return;
  campaignsSaveTimer = setTimeout(saveCampaignsNow, 1000);
}

function saveCampaignsNow() {
  clearTimeout(campaignsSaveTimer);
  campaignsSaveTimer = null;
  // mantém todas as ativas + as últimas MAX_FINISHED encerradas
  const finished = [...campaigns.values()].filter((c) => !ACTIVE.includes(c.status)).sort((a, b) => b.createdAt - a.createdAt);
  for (const c of finished.slice(MAX_FINISHED)) campaigns.delete(c.id);
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = CAMPAIGNS_FILE + '.tmp';
    const list = [...campaigns.values()].map(({ nextAt, waitingWindow, ...rest }) => rest);
    fs.writeFileSync(tmp, JSON.stringify(list), { mode: 0o600 }); // contém snapshot das credenciais do destino
    fs.renameSync(tmp, CAMPAIGNS_FILE);
  } catch (e) { console.warn('Falha ao salvar campanhas:', e.message); }
}

function launch(c) {
  runCampaign(c).catch((e) => {
    c.status = 'error';
    c.log.push({ index: c.cursor + 1, ok: false, status: 0, info: e.message, at: Date.now() });
    saveCampaignsNow();
  });
}

function loadCampaigns() {
  let list = [];
  try { list = JSON.parse(fs.readFileSync(CAMPAIGNS_FILE, 'utf8')); } catch { return; }
  if (!Array.isArray(list)) return;
  let resumed = 0;
  for (const c of list) {
    if (!c || !c.id || !Array.isArray(c.items) || !Array.isArray(c.steps)) continue;
    c.nextAt = null;
    c.waitingWindow = false;
    campaigns.set(c.id, c);
    if (ACTIVE.includes(c.status)) { launch(c); resumed++; }
  }
  if (resumed) console.log(`${resumed} campanha(s) agendada(s)/em andamento retomada(s).`);
}

// ---------- Execução ----------
// Cada contato recebe a sequência de mensagens (steps) em ordem, com uma espera aleatória antes de cada
// mensagem a partir da 2ª. Entre um contato e outro vale a cadência geral (intervalo + pausa por lote).
async function waitWhilePaused(c) {
  while (c.status === 'paused') await sleep(500);
  return c.status === 'running';
}

// Próximo passo (a partir de j) com conteúdo para este contato; -1 se não houver.
function nextStep(c, msgs, j) {
  for (; j < c.steps.length; j++) if (String(msgs[j] ?? '').trim() || c.steps[j].media) return j;
  return -1;
}

async function runCampaign(c) {
  const { cfg } = c;

  // Agendamento: aguarda o horário de início (status 'scheduled').
  while (c.status === 'scheduled' && Date.now() < c.startAt) {
    c.nextAt = c.startAt;
    await sleep(Math.min(1000, Math.max(50, c.startAt - Date.now())));
  }
  c.nextAt = null;
  if (c.status === 'scheduled') {
    c.status = 'running';
    c.startedAt = Date.now();
    saveCampaignsSoon();
  }

  while (c.cursor < c.items.length) {
    if (!(await waitWhilePaused(c))) return;
    // A janela de horário só é checada antes de começar um contato — uma sequência iniciada vai até o fim.
    if (!c.step) {
      while (!inWindow(cfg) && ACTIVE.includes(c.status)) {
        c.waitingWindow = true;
        await sleep(1000);
      }
      c.waitingWindow = false;
      if (c.status === 'paused') continue;
      if (c.status !== 'running') return;
    }

    const i = c.cursor;
    const item = c.items[i];
    const msgs = item.messages;
    let ok = true;
    let delivered = 0;
    let j = nextStep(c, msgs, c.step || 0);
    while (j >= 0) {
      if (!(await waitWhilePaused(c))) return;
      c.step = j;
      const st = c.steps[j];
      const result = await deliver(
        cfg.dest,
        { phone: item.phone, message: String(msgs[j] ?? ''), fields: item.fields },
        { campaign_id: c.id, index: i + 1, total: c.items.length, step: j + 1, steps: c.steps.length },
        st.media
      );
      c.log.push({ index: i + 1, step: j + 1, phone: item.phone, ok: result.ok, status: result.status, info: result.ok ? '' : result.body, at: Date.now() });
      if (c.log.length > 500) c.log.shift();
      c.step = j + 1;
      saveCampaignsSoon();
      if (!result.ok) { ok = false; break; } // não manda o resto da sequência se uma mensagem falhar
      delivered++;
      c.messagesSent = (c.messagesSent || 0) + 1;

      j = nextStep(c, msgs, j + 1);
      if (j < 0) break;
      const wait = rand(c.steps[j].delayMin, c.steps[j].delayMax) * 1000;
      c.nextAt = Date.now() + wait;
      await sleepInterruptible(c, wait);
      c.nextAt = null;
      if (c.status === 'canceled') return;
    }
    if (ok && !delivered && c.step === 0) {
      ok = false;
      c.log.push({ index: i + 1, phone: item.phone, ok: false, status: 0, info: 'todas as mensagens ficaram vazias para este contato', at: Date.now() });
    }

    c.cursor++;
    c.step = 0;
    if (ok) c.sent++;
    else c.failed++;
    saveCampaignsSoon();

    if (c.cursor >= c.items.length) break;
    c.sinceBatch = (c.sinceBatch || 0) + 1;
    let wait;
    if (cfg.batchSize > 0 && c.sinceBatch >= cfg.batchSize) {
      c.sinceBatch = 0;
      wait = cfg.batchPause * 1000;
    } else {
      wait = rand(cfg.minDelay, cfg.maxDelay) * 1000;
    }
    c.nextAt = Date.now() + wait;
    await sleepInterruptible(c, wait);
    c.nextAt = null;
  }
  if (c.status === 'running') {
    c.status = 'done';
    c.finishedAt = Date.now();
  }
  saveCampaignsNow();
}

async function sleepInterruptible(c, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end && c.status !== 'canceled') await sleep(Math.min(250, end - Date.now()));
}

function summary(c, withLog) {
  const first = c.items[0];
  const out = {
    id: c.id,
    status: c.status,
    total: c.items.length,
    sent: c.sent,
    failed: c.failed,
    messagesSent: c.messagesSent || 0,
    steps: c.steps.length,
    createdAt: c.createdAt,
    startAt: c.startAt || null,
    startedAt: c.startedAt || null,
    finishedAt: c.finishedAt || null,
    nextAt: c.nextAt,
    waitingWindow: !!c.waitingWindow,
    preview: first ? String(first.messages.find((m) => String(m).trim()) || '').slice(0, 80) : '',
  };
  if (withLog) out.log = c.log.slice(-100);
  return out;
}

// ---------- Validação do que vem do front ----------
const MAX_STEPS = 20;

// Passos da sequência: [{ mediaId, delayMin, delayMax }]. Formato antigo (sem steps) = 1 passo com body.mediaId.
function parseSteps(req, body) {
  const raw = Array.isArray(body.steps) && body.steps.length ? body.steps : [{ mediaId: body.mediaId }];
  if (raw.length > MAX_STEPS) return { error: `No máximo ${MAX_STEPS} mensagens por sequência` };
  const steps = [];
  for (let j = 0; j < raw.length; j++) {
    const s = raw[j] || {};
    const media = resolveMedia(req, s.mediaId);
    if (media === undefined) return { error: `Anexo da mensagem ${j + 1} não encontrado. Anexe novamente.` };
    const delayMin = j ? Math.max(0, Number(s.delayMin) || 0) : 0;
    const delayMax = j ? Math.max(delayMin, Number(s.delayMax) || delayMin) : 0;
    steps.push({ media, delayMin, delayMax });
  }
  return { steps };
}

// Contatos: [{ phone, messages: [texto do passo 1, passo 2, ...], fields }]. Formato antigo: { message }.
function parseItems(rawItems, nSteps) {
  if (!Array.isArray(rawItems)) return [];
  return rawItems
    .filter((it) => it && typeof it.phone === 'string' && it.phone)
    .map((it) => {
      const msgs = Array.isArray(it.messages) ? it.messages : [it.message];
      return {
        phone: it.phone,
        messages: Array.from({ length: nSteps }, (_, j) => (typeof msgs[j] === 'string' ? msgs[j] : '')),
        fields: it.fields && typeof it.fields === 'object' ? it.fields : {},
      };
    });
}

// "2026-11-13T09:00" interpretado no horário de Brasília (sem horário de verão desde 2019: UTC-3).
function parseBrasilia(local) {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(String(local || ''))) return NaN;
  return new Date(local + ':00-03:00').getTime();
}

// Envia a sequência inteira para 1 contato. As esperas entre mensagens ficam limitadas a 10s no teste.
app.post('/api/test', async (req, res) => {
  const err = destError(settings);
  if (err) return res.status(400).json({ error: err });
  const parsed = parseSteps(req, req.body || {});
  if (parsed.error) return res.status(400).json({ error: parsed.error });
  const { steps } = parsed;
  const [item] = parseItems([req.body.item], steps.length);
  if (!item) return res.status(400).json({ error: 'Contato de teste inválido' });
  const fake = { steps };
  const results = [];
  let j = nextStep(fake, item.messages, 0);
  while (j >= 0) {
    const r = await deliver(settings, { phone: item.phone, message: item.messages[j], fields: item.fields },
      { campaign_id: 'teste', index: 1, total: 1, step: j + 1, steps: steps.length }, steps[j].media);
    results.push({ step: j + 1, ...r });
    if (!r.ok) break;
    j = nextStep(fake, item.messages, j + 1);
    if (j >= 0) await sleep(Math.min(10, steps[j].delayMin) * 1000);
  }
  const failed = results.find((r) => !r.ok);
  res.json({ ok: !failed && results.length > 0, results, ...(failed ? { status: failed.status, body: failed.body } : {}) });
});

// Teste de conexão do destino salvo. Evolution: consulta o estado da instância (não envia nada).
// N8N: envia um ping { event: 'ping', test: true } ao webhook.
app.post('/api/settings/test', async (req, res) => {
  const target = req.body && req.body.target === 'evolution' ? 'evolution' : 'n8n';
  const probe = { ...settings, mode: target };
  const err = destError(probe);
  if (err) return res.status(400).json({ error: err });
  if (target === 'evolution') {
    const r = await http(evoUrl(settings.evolution, '/instance/connectionState'), {
      method: 'GET', headers: { apikey: settings.evolution.apiKey },
    });
    let state = null;
    try { const j = JSON.parse(r.body); state = (j.instance && j.instance.state) || j.state || null; } catch {}
    return res.json({ ...r, state });
  }
  const n = settings.n8n;
  const headers = n.headerName && n.headerValue ? { [n.headerName]: n.headerValue } : {};
  res.json(await http(n.url, { headers, body: { event: 'ping', test: true } }));
});

app.post('/api/campaigns', (req, res) => {
  const err = destError(settings);
  if (err) return res.status(400).json({ error: err });
  const b = req.body || {};
  const parsed = parseSteps(req, b);
  if (parsed.error) return res.status(400).json({ error: parsed.error });
  const { steps } = parsed;
  const items = parseItems(b.items, steps.length);
  if (!items.length) return res.status(400).json({ error: 'Nenhum contato para enviar' });

  let startAt = null;
  if (b.scheduleAt) {
    startAt = parseBrasilia(b.scheduleAt);
    if (!Number.isFinite(startAt)) return res.status(400).json({ error: 'Data/hora de agendamento inválida' });
    if (startAt < Date.now() - 60000) return res.status(400).json({ error: 'A data/hora de agendamento já passou' });
  }

  const minDelay = Math.max(0, Number(b.minDelay) || 0);
  const maxDelay = Math.max(minDelay, Number(b.maxDelay) || minDelay);
  const c = {
    id: crypto.randomUUID(),
    status: startAt ? 'scheduled' : 'running',
    startAt,
    startedAt: startAt ? null : Date.now(),
    items,
    steps,
    cursor: 0,
    step: 0,
    sinceBatch: 0,
    sent: 0,
    failed: 0,
    messagesSent: 0,
    log: [],
    nextAt: null,
    createdAt: Date.now(),
    cfg: {
      dest: structuredClone(settings), // snapshot: mudar as configurações não afeta campanhas em andamento/agendadas
      minDelay,
      maxDelay,
      batchSize: Math.max(0, parseInt(b.batchSize, 10) || 0),
      batchPause: Math.max(0, Number(b.batchPause) || 0),
      windowEnabled: !!b.windowEnabled,
      windowStart: /^\d{1,2}:\d{2}$/.test(b.windowStart) ? b.windowStart : '09:00',
      windowEnd: /^\d{1,2}:\d{2}$/.test(b.windowEnd) ? b.windowEnd : '18:00',
      days: (Array.isArray(b.days) ? b.days : []).map(Number).filter((d) => d >= 0 && d <= 6),
    },
  };
  campaigns.set(c.id, c);
  saveCampaignsNow();
  launch(c);
  res.status(201).json(summary(c));
});

app.get('/api/campaigns', (req, res) => {
  res.json([...campaigns.values()].sort((a, b) => b.createdAt - a.createdAt).map((c) => summary(c)));
});

app.get('/api/campaigns/:id', (req, res) => {
  const c = campaigns.get(req.params.id);
  if (!c) return res.status(404).json({ error: 'não encontrada' });
  res.json(summary(c, true));
});

app.post('/api/campaigns/:id/:action', (req, res) => {
  const c = campaigns.get(req.params.id);
  if (!c) return res.status(404).json({ error: 'não encontrada' });
  const { action } = req.params;
  if (action === 'pause' && c.status === 'running') c.status = 'paused';
  else if (action === 'resume' && c.status === 'paused') c.status = 'running';
  else if (action === 'start' && c.status === 'scheduled') c.startAt = Date.now(); // iniciar agora
  else if (action === 'cancel' && ACTIVE.includes(c.status)) { c.status = 'canceled'; c.finishedAt = Date.now(); }
  else if (action === 'remove' && !ACTIVE.includes(c.status)) {
    campaigns.delete(c.id);
    saveCampaignsNow();
    return res.json({ ok: true, removed: true });
  }
  saveCampaignsNow();
  res.json(summary(c));
});

loadCampaigns();

app.listen(PORT, () => {
  console.log(`Disparador rodando na porta ${PORT}`);
  console.log('Dados persistidos em', DATA_DIR);
  if (!APP_PASSWORD) console.warn('ATENÇÃO: APP_PASSWORD não definido — a aplicação está sem login!');
});
